import { useState, useEffect, useCallback } from 'react';
import { Scale } from 'lucide-react';
import { Processo } from '@/lib/types';
import { getProcessos, saveProcessos, updateProcesso } from '@/lib/store';
import { ExcelUpload } from '@/components/ExcelUpload';
import { ProcessoTable } from '@/components/ProcessoTable';
import { toast } from 'sonner';

const Index = () => {
  const [processos, setProcessos] = useState<Processo[]>([]);

  useEffect(() => {
    setProcessos(getProcessos());
  }, []);

  const handleUpload = useCallback((novos: Processo[]) => {
    const atuais = getProcessos();
    const merged = [...atuais, ...novos];
    saveProcessos(merged);
    setProcessos(merged);
    toast.success(`${novos.length} processos importados com sucesso!`);
  }, []);

  const handleUpdate = useCallback((id: string, updates: Partial<Processo>) => {
    const updated = updateProcesso(id, updates);
    setProcessos([...updated]);
  }, []);

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card/80 backdrop-blur-sm sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-xl bg-primary flex items-center justify-center">
              <Scale className="h-5 w-5 text-primary-foreground" />
            </div>
            <div>
              <h1 className="text-xl font-bold font-['Space_Grotesk'] text-foreground">
                Processos Aptos
              </h1>
              <p className="text-xs text-muted-foreground">
                Acompanhamento de encerramento
              </p>
            </div>
          </div>
          <ExcelUpload onUpload={handleUpload} />
        </div>
      </header>

      {/* Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
        <ProcessoTable processos={processos} onUpdate={handleUpdate} />
      </main>
    </div>
  );
};

export default Index;
