import { useCallback } from 'react';
import * as XLSX from 'xlsx';
import { Upload } from 'lucide-react';
import { Processo } from '@/lib/types';
import { Button } from '@/components/ui/button';

interface ExcelUploadProps {
  onUpload: (processos: Processo[]) => void;
}

function normalizeHeader(h: string): string {
  const s = h.trim().toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  if (s === 'gcpj') return 'gcpj';
  if (s === 'processo') return 'processo';
  if (s === 'oj') return 'oj';
  if (s.includes('numero') || s.includes('sigla')) return 'numeroSigla';
  if (s === 'autor') return 'autor';
  if (s === 'comarca') return 'comarca';
  if (s === 'uf') return 'uf';
  if (s === 'grupo') return 'grupo';
  if (s.includes('acao') || s.includes('ação')) return 'acao';
  return s;
}

export function ExcelUpload({ onUpload }: ExcelUploadProps) {
  const handleFile = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (evt) => {
      const data = evt.target?.result;
      const wb = XLSX.read(data, { type: 'array' });
      const ws = wb.Sheets[wb.SheetNames[0]];
      const rows = XLSX.utils.sheet_to_json<Record<string, string>>(ws, { defval: '' });

      const processos: Processo[] = rows.map((row, i) => {
        const mapped: Record<string, string> = {};
        Object.entries(row).forEach(([key, val]) => {
          mapped[normalizeHeader(key)] = String(val);
        });

        return {
          id: `proc-${Date.now()}-${i}`,
          gcpj: mapped.gcpj || '',
          processo: mapped.processo || '',
          oj: mapped.oj || '',
          numeroSigla: mapped.numeroSigla || '',
          autor: mapped.autor || '',
          comarca: mapped.comarca || '',
          uf: mapped.uf || '',
          grupo: mapped.grupo || '',
          acao: mapped.acao || '',
          status: 'pendente',
          observacoes: '',
        };
      });

      onUpload(processos);
    };
    reader.readAsArrayBuffer(file);
    e.target.value = '';
  }, [onUpload]);

  return (
    <Button variant="outline" asChild className="gap-2 border-dashed border-2 border-primary/30 hover:border-primary hover:bg-primary/5 transition-all">
      <label className="cursor-pointer">
        <Upload className="h-4 w-4" />
        Importar Planilha Excel
        <input type="file" accept=".xlsx,.xls,.csv" onChange={handleFile} className="hidden" />
      </label>
    </Button>
  );
}
