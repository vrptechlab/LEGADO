import { useState, useMemo } from 'react';
import { Processo } from '@/lib/types';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Search, Eye, FileText } from 'lucide-react';

interface ProcessoTableProps {
  processos: Processo[];
  onUpdate: (id: string, updates: Partial<Processo>) => void;
}

const statusConfig = {
  pendente: { label: 'Pendente', className: 'bg-warning/15 text-warning border-warning/30' },
  em_analise: { label: 'Em Análise', className: 'bg-primary/15 text-primary border-primary/30' },
  encerrado: { label: 'Encerrado', className: 'bg-[hsl(152,60%,40%)]/15 text-[hsl(152,60%,40%)] border-[hsl(152,60%,40%)]/30' },
};

export function ProcessoTable({ processos, onUpdate }: ProcessoTableProps) {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('todos');
  const [selected, setSelected] = useState<Processo | null>(null);

  const filtered = useMemo(() => {
    return processos.filter(p => {
      const matchSearch = !search || Object.values(p).some(v =>
        String(v).toLowerCase().includes(search.toLowerCase())
      );
      const matchStatus = statusFilter === 'todos' || p.status === statusFilter;
      return matchSearch && matchStatus;
    });
  }, [processos, search, statusFilter]);

  const counts = useMemo(() => ({
    total: processos.length,
    pendente: processos.filter(p => p.status === 'pendente').length,
    em_analise: processos.filter(p => p.status === 'em_analise').length,
    encerrado: processos.filter(p => p.status === 'encerrado').length,
  }), [processos]);

  return (
    <div className="space-y-6">
      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: 'Total', value: counts.total, color: 'bg-primary/10 text-primary' },
          { label: 'Pendentes', value: counts.pendente, color: 'bg-warning/10 text-warning' },
          { label: 'Em Análise', value: counts.em_analise, color: 'bg-primary/10 text-primary' },
          { label: 'Encerrados', value: counts.encerrado, color: 'bg-[hsl(152,60%,40%)]/10 text-[hsl(152,60%,40%)]' },
        ].map(s => (
          <div key={s.label} className={`rounded-xl p-4 ${s.color}`}>
            <p className="text-sm font-medium opacity-80">{s.label}</p>
            <p className="text-3xl font-bold font-['Space_Grotesk']">{s.value}</p>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Buscar por GCPJ, autor, comarca..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="pl-10"
          />
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-full sm:w-48">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="todos">Todos os Status</SelectItem>
            <SelectItem value="pendente">Pendente</SelectItem>
            <SelectItem value="em_analise">Em Análise</SelectItem>
            <SelectItem value="encerrado">Encerrado</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Table */}
      {filtered.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20 text-muted-foreground">
          <FileText className="h-12 w-12 mb-4 opacity-40" />
          <p className="text-lg font-medium">Nenhum processo encontrado</p>
          <p className="text-sm">Importe uma planilha Excel para começar</p>
        </div>
      ) : (
        <div className="rounded-xl border bg-card overflow-hidden shadow-sm">
          <Table>
            <TableHeader>
              <TableRow className="bg-muted/50">
                <TableHead className="font-semibold">GCPJ</TableHead>
                <TableHead className="font-semibold">Processo</TableHead>
                <TableHead className="font-semibold hidden md:table-cell">Autor</TableHead>
                <TableHead className="font-semibold hidden lg:table-cell">Comarca</TableHead>
                <TableHead className="font-semibold hidden lg:table-cell">UF</TableHead>
                <TableHead className="font-semibold">Status</TableHead>
                <TableHead className="font-semibold w-12"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.map(p => {
                const sc = statusConfig[p.status];
                return (
                  <TableRow key={p.id} className="hover:bg-muted/30 transition-colors">
                    <TableCell className="font-mono text-sm">{p.gcpj}</TableCell>
                    <TableCell className="font-medium max-w-[200px] truncate">{p.processo}</TableCell>
                    <TableCell className="hidden md:table-cell">{p.autor}</TableCell>
                    <TableCell className="hidden lg:table-cell">{p.comarca}</TableCell>
                    <TableCell className="hidden lg:table-cell">{p.uf}</TableCell>
                    <TableCell>
                      <Badge variant="outline" className={sc.className}>{sc.label}</Badge>
                    </TableCell>
                    <TableCell>
                      <Button variant="ghost" size="icon" onClick={() => setSelected(p)}>
                        <Eye className="h-4 w-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
      )}

      {/* Detail Dialog */}
      <Dialog open={!!selected} onOpenChange={() => setSelected(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="font-['Space_Grotesk']">Detalhes do Processo</DialogTitle>
          </DialogHeader>
          {selected && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-3 text-sm">
                {[
                  ['GCPJ', selected.gcpj],
                  ['Processo', selected.processo],
                  ['OJ', selected.oj],
                  ['Nº / Sigla', selected.numeroSigla],
                  ['Autor', selected.autor],
                  ['Comarca', selected.comarca],
                  ['UF', selected.uf],
                  ['Grupo', selected.grupo],
                  ['Ação', selected.acao],
                ].map(([label, value]) => (
                  <div key={label}>
                    <p className="text-muted-foreground text-xs">{label}</p>
                    <p className="font-medium">{value || '—'}</p>
                  </div>
                ))}
              </div>

              <div>
                <p className="text-xs text-muted-foreground mb-1">Status</p>
                <Select
                  value={selected.status}
                  onValueChange={(v) => {
                    onUpdate(selected.id, { status: v as Processo['status'] });
                    setSelected({ ...selected, status: v as Processo['status'] });
                  }}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pendente">Pendente</SelectItem>
                    <SelectItem value="em_analise">Em Análise</SelectItem>
                    <SelectItem value="encerrado">Encerrado</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <p className="text-xs text-muted-foreground mb-1">Observações</p>
                <Textarea
                  value={selected.observacoes}
                  onChange={e => {
                    const obs = e.target.value;
                    onUpdate(selected.id, { observacoes: obs });
                    setSelected({ ...selected, observacoes: obs });
                  }}
                  placeholder="Adicione observações sobre o encerramento..."
                  rows={3}
                />
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
