import { Processo } from './types';

const STORAGE_KEY = 'processos-aptos';

export function getProcessos(): Processo[] {
  const data = localStorage.getItem(STORAGE_KEY);
  return data ? JSON.parse(data) : [];
}

export function saveProcessos(processos: Processo[]) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(processos));
}

export function updateProcesso(id: string, updates: Partial<Processo>) {
  const processos = getProcessos();
  const idx = processos.findIndex(p => p.id === id);
  if (idx !== -1) {
    processos[idx] = { ...processos[idx], ...updates };
    saveProcessos(processos);
  }
  return processos;
}
