export interface Processo {
  id: string;
  gcpj: string;
  processo: string;
  oj: string;
  numeroSigla: string;
  autor: string;
  comarca: string;
  uf: string;
  grupo: string;
  acao: string;
  status: 'pendente' | 'em_analise' | 'encerrado';
  observacoes: string;
}
